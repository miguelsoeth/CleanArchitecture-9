﻿namespace Clean.Architecture.Web.ContributorEndpoints;

public record ContributorRecord(int Id, string Name);
